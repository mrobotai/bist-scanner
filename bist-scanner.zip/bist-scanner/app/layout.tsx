import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BIST EMA 5/8/13 Tarayıcı",
  description: "Ribbon Crossover — 17:50 Emir Sinyali",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
